from setuptools import find_packages, setup

package_name = "minimal_opcua_test"

setup(
    name=package_name,
    version="0.0.0",
    packages=find_packages(exclude=["test"]),
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
    ],
    install_requires=[
        "setuptools",
        "python-snap7",
        "opcua",
    ],
    zip_safe=True,
    maintainer="mugugu",
    maintainer_email="mugugujose@gmail.com",
    description="TODO: Package description",
    license="TODO: License declaration",
    tests_require=["pytest"],
    entry_points={
        "console_scripts": [
            "minimal_opcua_node=minimal_opcua_test.minimal_opcua_node:main",
            "min_opcua_connect_only=minimal_opcua_test.min_opcua_connect_only:main",
            "min_write_onyl=minimal_opcua_test.min_write_onyl:main",
            "min_write_once_only=minimal_opcua_test.min_write_once_only:main",
            "min_write_read=minimal_opcua_test.min_write_read:main",
            "min_write_read_pose=minimal_opcua_test.min_write_read_pose:main",
            "min_write_jointstates=minimal_opcua_test.min_write_jointstates:main",
            "min_write_jointstates1=minimal_opcua_test.min_write_jointstates1:main",
            "min_write_jointstates2=minimal_opcua_test.min_write_read_jointstates2:main",
            "min_write_jointstates3=minimal_opcua_test.min_write_read_jointstates3:main",
        ],
    },
)
